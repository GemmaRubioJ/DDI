INSERT INTO REGION (nombre) VALUES ('Pueblo Paleta');
INSERT INTO REGION ( nombre) VALUES ('Pueblo Esmeralda');
INSERT INTO REGION (nombre) VALUES ('Pueblo Zafiro');
INSERT INTO REGION (nombre) VALUES ('Montaña Nevada');

INSERT INTO ENTRENADOR (nombre, active) VALUES ('Ash', 0);
INSERT INTO ENTRENADOR (nombre, active) VALUES ('Misty', 0);
INSERT INTO ENTRENADOR (nombre, active) VALUES ('Maka', 0);
INSERT INTO ENTRENADOR (nombre, active) VALUES ('Brooke', 0);

INSERT INTO POKEMON (nombre, region, entrenador) VALUES ('Pikachu', '1', '1');
INSERT INTO POKEMON (nombre, region, entrenador) VALUES ('Ponita', '2', '2');
INSERT INTO POKEMON (nombre, region, entrenador) VALUES ('Charizar', '3', '2');
INSERT INTO POKEMON (nombre, region, entrenador) VALUES ('Bulbasaur', '4', '4');
INSERT INTO POKEMON (nombre, region, entrenador) VALUES ('Vaporeon', '1', '3');