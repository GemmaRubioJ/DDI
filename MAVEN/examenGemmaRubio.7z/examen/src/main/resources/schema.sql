CREATE TABLE IF NOT EXISTS REGION(
   id INT NOT NULL PRIMARY KEY auto_increment,
   nombre varchar(25)
);

CREATE TABLE IF NOT EXISTS ENTRENADOR(
    id INT NOT NULL PRIMARY KEY auto_increment,
    nombre varchar(50),
    active BOOLEAN
);

CREATE TABLE IF NOT EXISTS POKEMON(
   id INT NOT NULL PRIMARY KEY auto_increment,
   nombre varchar(50),
   region INT,
   entrenador INT,
   FOREIGN KEY (region) REFERENCES REGION(id) ON DELETE CASCADE,
   FOREIGN KEY (entrenador) REFERENCES ENTRENADOR(id)
);
