package com.example.examen.Repositorios;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.example.examen.Modelos.Entrenador;



public class EntrenadorRowMapper implements RowMapper<Entrenador>{
    
    @Override
    public Entrenador mapRow(ResultSet rs, int rowNum) throws SQLException {
        Entrenador entrenador = new Entrenador();
        entrenador.setId(rs.getInt("id"));
        entrenador.setNombre(rs.getString("nombre"));
        entrenador.setActive(rs.getBoolean("active"));

        return entrenador;
    
    }
}
