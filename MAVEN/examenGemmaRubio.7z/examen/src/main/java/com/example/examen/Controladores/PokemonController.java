package com.example.examen.Controladores;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import com.example.examen.Modelos.Pokemon;
import com.example.examen.Repositorios.PokemonRepositorio;

@Controller
public class PokemonController {
    
    @Autowired
    private PokemonRepositorio pokemonRepositorio;
    
    @RequestMapping("/insertarPokemon")
    public String insertarPokemon(Pokemon pokemon, Model model){
        pokemonRepositorio.insertarPokemon(pokemon);
        return listaPokemon(model);
    }

    @RequestMapping("/listaPokemon")
    public String listaPokemon(Model model){
        List<Pokemon> listaPokemon = pokemonRepositorio.getTodosPokemon();
        model.addAttribute("listaPokemon", listaPokemon);
        return "listaPokemon";
    }

    @RequestMapping("/eliminarPokemon/{id}")
    public String eliminarPokemon(@PathVariable int id, Model model){
        Pokemon pokemon = pokemonRepositorio.getPokemonPorId(id);
        if (pokemon != null){
            pokemonRepositorio.eliminarPokemon(pokemon);
            return listaPokemon(model);
        }
        else {
            return "index";
        }
    }
}
