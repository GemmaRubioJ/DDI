package com.example.examen.Controladores;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.example.examen.Modelos.Entrenador;
import com.example.examen.Repositorios.EntrenadorRepositorio;

@Controller
public class EntrenadorController {
    
    @Autowired
    private EntrenadorRepositorio entrenadorRepositorio;

    @RequestMapping("/insertarEntrenador")
    public String insertarEntrenador(Entrenador entrenador, Model model){
        entrenadorRepositorio.insertarEntrenador(entrenador);
        return "index";
    }
}
