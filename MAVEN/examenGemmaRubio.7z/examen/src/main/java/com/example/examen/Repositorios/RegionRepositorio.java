package com.example.examen.Repositorios;

import java.util.List;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;


import com.example.examen.Modelos.Region;

@Repository
public class RegionRepositorio {
    
    @Autowired
    JdbcTemplate jdbcTemplate;
    
    public List<Region> getTodasRegiones() {
        String query ="SELECT * from REGION;";
        List<Region> listaRegiones = jdbcTemplate.query(query, new RegionRowMapper());
        return listaRegiones;
    }

    public void insertarRegion (Region region){
        String query = "INSERT INTO REGION (nombre) VALUES(? );";
        jdbcTemplate.update(query, region.getId(), region.getNombre());
    }

    public Region getRegionPorId (int id){
        String query = "SELECT * FROM REGION r WHERE r.id = ?";
        List<Region> listaRegiones = jdbcTemplate.query(query, new RegionRowMapper(), id);
        return (listaRegiones.isEmpty())? null: listaRegiones.get(0);
    }

    public void eliminarRegion(Region region){
        String query = "DELETE FROM REGION r WHERE r.id = ?";
        jdbcTemplate.update(query, region.getId());
    }
}
