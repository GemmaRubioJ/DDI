package com.example.examen.Repositorios;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.example.examen.Modelos.Entrenador;

@Repository
public class EntrenadorRepositorio {
    
    @Autowired
    JdbcTemplate jdbcTemplate;

    public void insertarEntrenador (Entrenador entrenador){
        String query = "INSERT INTO ENTRENADOR (nombre, active) VALUES(?, ?)";
        jdbcTemplate.update(query, entrenador.getNombre(), entrenador.getActive());
    }
}
