package com.example.examen.Repositorios;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.example.examen.Modelos.Entrenador;
import com.example.examen.Modelos.Pokemon;
import com.example.examen.Modelos.Region;

public class PokemonRowMapper  implements RowMapper<Pokemon>{
    
    @Override
    public Pokemon mapRow(ResultSet rs, int rowNum) throws SQLException {

        Pokemon pokemon = new Pokemon();
        pokemon.setId(rs.getInt("id"));
        pokemon.setNombre(rs.getString("nombre"));

        Region region = new Region();
        region.setId(rs.getInt("region"));
        Entrenador entrenador = new Entrenador();
        entrenador.setId(rs.getInt("entrenador"));

        pokemon.setRegion(region);
        pokemon.setEntrenador(entrenador);
        return pokemon;
    }
}
