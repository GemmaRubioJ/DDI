package com.example.examen.Controladores;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import com.example.examen.Modelos.Region;
import com.example.examen.Repositorios.RegionRepositorio;

public class RegionController {

    @Autowired 
    private RegionRepositorio regionRepositorio;

    @RequestMapping("/insertarRegion")
    public String insertarRegion(Region region, Model model){
        regionRepositorio.insertarRegion(region);
        return listaRegiones(model);
    }

    @RequestMapping("/listaRegiones")
    public String listaRegiones(Model model){
        List<Region> listaRegiones = regionRepositorio.getTodasRegiones();
        model.addAttribute("listaRegiones", listaRegiones);
        return "listaRegiones";
    }

    @RequestMapping("/eliminarRegión/{id}")
    public String eliminarRegion(@PathVariable int id, Model model){
        Region region = regionRepositorio.getRegionPorId(id);
        if (region != null){
            regionRepositorio.eliminarRegion(region);
            return listaRegiones(model);
        } else{
            return "index";
        }
    }
}
