package com.example.examen.Repositorios;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.example.examen.Modelos.Pokemon;

@Repository
public class PokemonRepositorio {
    
    @Autowired
    JdbcTemplate jdbcTemplate;

    public List<Pokemon> getTodosPokemon() {
        String query = "SELECT * FROM POKEMON";
        List<Pokemon> listaPokemon = jdbcTemplate.query(query, new PokemonRowMapper());
        return listaPokemon;
    }

    public void insertarPokemon (Pokemon pokemon){
        String query = "INSERT INTO POKEMON (nombre, region, entrenador) VALUES(?, ?, ?)";
        jdbcTemplate.update(query, pokemon.getId(), pokemon.getNombre(), pokemon.getRegion().getId(), pokemon.getEntrenador().getId());
    }

    public void eliminarPokemon(Pokemon pokemon){
        String query = "DELETE FROM POKEMON p WHERE p.nombre = ?";
        jdbcTemplate.update(query, pokemon.getNombre());
    }

    public Pokemon getPokemonPorId (int id){
        String query = "SELECT * FROM POKEMON p WHERE p.id = ?";
        List<Pokemon> listaPokemon = jdbcTemplate.query(query, new PokemonRowMapper(), id);
        return (listaPokemon.isEmpty())? null: listaPokemon.get(0);
    }
}
